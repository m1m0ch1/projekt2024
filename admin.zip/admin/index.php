<?php

require_once "../header.php"

?>

    <main class="login-container">
        <form class="login-form" action="login.php" method="POST">
            <label for="email">Email:</label>
            <input type="text" id="email" name="email" required>
            
            <label for="jelszo">Jelszó:</label>
            <input type="password" id="jelszo" name="jelszo" required>
            
            <button type="submit">Bejelentkezés</button>
        </form>
    </main>

<?php

require_once "../footer.php"

?>