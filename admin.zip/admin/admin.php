<?php
require "../api.php";

// elindítjuk a sütikezelést
session_start();

// védjük az admin felületet
// csak ha bejelenetkezett igaz, akkor jelenik meg
if( $_SESSION["bejelentkezett"] == true ){

  echo "<h1>Admin felület</h1>";
  echo "<a href='logout.php'>Kijelentkezés  </a>";

  showTable("users");
  showTable("purchase");
  showTable("products");

  // id	name	category	price	description	pic
  echo "
  <form method='post'>
    <input type='hidden' name='insert' value='insert'>
    <p> Terméknév: <input type='text' name='name'> </p>
    <p> Kategória: <input type='text' name='category'> </p>
    <p> Ár: <input type='text' name='price'> </p>
    <p> Leírás: <input type='text' name='description'> </p>
    <p> Kép url: <input type='text' name='pic'> </p>
    <p> <input type='submit' value='Beszúrás'> </p>
  </form>
  ";
  if( $_POST["insert"] ){
    print_r( $_POST );
    insertTable("products", $_POST );
  }
  
}
else
{
  echo "<p>Nincs bejelentkezve!</p>";
}
