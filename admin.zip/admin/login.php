<?php

require_once "../api.php";

// ez egy sütit rak le a böngészőbe
// ami adatokat tárolhat
// ez jelzi, hogy valaki bejelentkezett
// munkamenet
session_start();

// $_POST egy beépített változó
// ebbe kerülnek az űrlap adatai
// admin@admin.hu admin
$allusers = getTable("users");

//  test@gmail.com      asdf123
//   krisztina.farkas@gmail.com   farkas2021

$ok = false;
foreach($allusers as $user)
{  
  if($_POST["email"]  == $user["email"] &&  $_POST["jelszo"] == $user["password"]  &&  $user["isadmin"] == 1    )
  {
    $ok = true;
  }
}


if( $ok )
{
  $_SESSION["bejelentkezett"] = true;

  header("Location: admin.php");
}
else
{
  echo "Rossz email vagy jelszó.";
  echo "<a href='/admin/index.html'>Vissza az előző oldalra</a>";
}